package com.example.geminiagent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        val key = EditText(this).apply { hint = "Gemini API key"; setText(p.getString("key", "")) }
        val model = EditText(this).apply { hint = "Модель"; setText(p.getString("model", "gemini-2.5-flash")) }
        val modes = listOf("both" to "Экран: скриншот + дерево (лучше всего)", "shot" to "Только скриншот (игры, Flutter)", "text" to "Только дерево (быстро, дёшево)")
        val rg = RadioGroup(this)
        modes.forEachIndexed { i, m -> rg.addView(RadioButton(this).apply { id = 100 + i; text = m.second; isChecked = p.getString("mode", "both") == m.first }) }
        val confirm = CheckBox(this).apply { text = "Спрашивать голосом перед отправкой/оплатой/удалением"; isChecked = p.getBoolean("confirm", true) }
        val name = EditText(this).apply { hint = "Как к тебе обращаться (сэр, босс…)"; setText(p.getString("name", "сэр")) }
        val narrate = CheckBox(this).apply { text = "Джарвис комментирует шаги вслух"; isChecked = p.getBoolean("narrate", true) }
        val steps = EditText(this).apply { hint = "Макс. шагов"; setText(p.getInt("steps", 40).toString()) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        l.addView(TextView(this).apply { text = """КАК ПОЛЬЗОВАТЬСЯ

Настройка (один раз):
1. Вставь ключ Gemini (aistudio.google.com/apikey) и нажми «Сохранить».
2. Нажми «Разрешить микрофон».
3. Нажми «Включить сервис», найди «Gemini Agent» в списке, включи и подтверди. Если переключатель серый: Настройки → Приложения → Gemini Agent → ⋮ → «Разрешить ограниченные настройки», потом снова включи.
4. Выйди на любой экран: внизу появится круглая кнопка ✦.

Работа:
• Тап по ✦ → после «Слушаю» скажи задачу.
• Тап по ✦ во время работы → стоп.
• Перетащи ✦ пальцем, чтобы переместить.

Примеры команд:
• «Зайди в ютуб, найди Мистер Бист и включи новое видео»
• «Поставь будильник на 7:30»
• «Включи фонарик и сделай потише»
• «Открой заметки и допиши: купить молоко»
• «Какая завтра погода?» (ответит вслух)

Режимы экрана:
• Скриншот + дерево — точнее всего.
• Только скриншот — для игр и приложений без доступных элементов.
• Только дерево — быстро и дёшево.

Советы:
• Говори задачу целиком и чётко, одной фразой.
• Если завис — нажми ✦ и повтори задачу по-другому.
• После обновления приложения выключи и снова включи сервис.
• Экраны с защитой (банки) агент не видит.
• Скриншоты уходят в Gemini API; для личных приложений ставь «Только дерево».
• Подтверждения голосом перед отправкой/оплатой — галочка ниже.

НАСТРОЙКИ
"""; textSize = 15f })
        l.addView(TextView(this).apply { text = "1) Ключ с aistudio.google.com/apikey" })
        l.addView(key); l.addView(model); l.addView(name); l.addView(rg); l.addView(confirm); l.addView(narrate); l.addView(steps)
        l.addView(btn("Сохранить") {
            p.edit().putString("key", key.text.toString().trim()).putString("model", model.text.toString().trim())
                .putString("mode", modes[(rg.checkedRadioButtonId - 100).coerceIn(0, 2)].first).putBoolean("confirm", confirm.isChecked).putString("name", name.text.toString().trim()).putBoolean("narrate", narrate.isChecked)
                .putInt("steps", steps.text.toString().toIntOrNull() ?: 40).apply()
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        })
        l.addView(btn("2) Разрешить микрофон") { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) })
        l.addView(btn("3) Включить сервис «Gemini Agent»") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
