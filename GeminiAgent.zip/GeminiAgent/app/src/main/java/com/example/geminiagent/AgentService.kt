package com.example.geminiagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class AgentService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var btn: TextView
    private lateinit var wm: WindowManager
    private var tts: TextToSpeech? = null
    private var nodes = listOf<AccessibilityNodeInfo>()
    @Volatile private var running = false
    private var recognizer: SpeechRecognizer? = null
    private val cfg get() = getSharedPreferences("cfg", MODE_PRIVATE)

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) {
            tts?.language = Locale("ru"); tts?.setPitch(0.85f); tts?.setSpeechRate(1.05f)
            tts?.voices?.firstOrNull { v -> v.locale.language == "ru" && v.name.contains("male") && !v.name.contains("female") }?.let { v -> tts?.voice = v }
            speak("Системы активны. К вашим услугам, $me.")
        }
        val d = resources.displayMetrics.density
        btn = TextView(this).apply {
            text = "✦"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; elevation = 12f
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF4285F4.toInt(), 0xFF9B72CB.toInt(), 0xFFD96570.toInt())).apply { shape = GradientDrawable.OVAL }
        }
        val lp = WindowManager.LayoutParams((56 * d).toInt(), (56 * d).toInt(), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (90 * d).toInt() }
        var sx = 0f; var sy = 0f; var oy = 0; var ox = 0; var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> if (Math.abs(e.rawX - sx) > 20 || Math.abs(e.rawY - sy) > 20) {
                    moved = true; lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy - (e.rawY - sy).toInt(); wm.updateViewLayout(btn, lp) }
                MotionEvent.ACTION_UP -> if (!moved) { if (running) { tts?.stop(); stop("Остановлено"); speak(pick("Отменяю, $me.", "Как скажете, $me. Останавливаюсь.")) } else listen() }
            }; true
        }
        wm.addView(btn, lp)
    }

    private fun toast(s: String) = ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun stop(msg: String) { running = false; ui.post { btn.text = "✦" }; toast(msg) }

    private val me get() = cfg.getString("name", "сэр")?.ifBlank { "сэр" } ?: "сэр"
    private fun pick(vararg v: String) = v.random()

    private fun speak(s: String, wait: Boolean = false) {
        val l = CountDownLatch(1); val id = "u" + System.nanoTime()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { if (u == id) l.countDown() }
            @Deprecated("") override fun onError(u: String?) { if (u == id) l.countDown() }
        })
        tts?.speak(s, TextToSpeech.QUEUE_ADD, null, id)
        if (wait) l.await(25, TimeUnit.SECONDS)
    }

    private fun listenOnce(cb: (String?) -> Unit) {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) { btn.text = if (running) "■" else "✦"; cb(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()) }
                override fun onError(e: Int) { btn.text = if (running) "■" else "✦"; cb(null) }
                override fun onReadyForSpeech(p: Bundle?) { btn.text = "🎤" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"))
        }
    }

    private fun listen() {
        Thread {
            speak(pick("Слушаю, $me.", "К вашим услугам, $me.", "Да, $me?", "Весь внимание."), true)
            ui.post { listenOnce { t -> if (t.isNullOrBlank()) { toast("Не расслышал"); speak("Прошу прощения, $me, я вас не расслышал.") } else start(t) } }
        }.start()
    }

    private fun ask(q: String): String {
        speak(q, true); val l = CountDownLatch(1); var ans = ""
        ui.post { listenOnce { ans = it ?: ""; l.countDown() } }
        l.await(25, TimeUnit.SECONDS)
        return if (ans.isBlank()) "пользователь не ответил" else "ответ пользователя: $ans"
    }

    private fun start(task: String) {
        running = true; ui.post { btn.text = "■" }; toast("Задача: $task"); speak(pick("Приступаю, $me.", "Будет сделано, $me.", "Разумеется, $me.", "Уже занимаюсь этим."))
        Thread {
            val history = mutableListOf<String>()
            val maxSteps = cfg.getInt("steps", 40)
            try {
                for (step in 1..maxSteps) {
                    if (!running) return@Thread
                    val mode = cfg.getString("mode", "both")
                    val screen = if (mode == "shot") "(дерево отключено, ориентируйся по скриншоту и x,y)" else readScreen()
                    val shot = if (mode == "text") null else screenshot()
                    val prompt = "Задача: $task\n\nУже сделано:\n${history.takeLast(15).joinToString("\n").ifEmpty { "(ничего)" }}\n\n" +
                        (if (shot != null) "К сообщению приложен скриншот текущего экрана.\n" else "") + "Элементы экрана (id|тип|текст|описание|флаги):\n$screen"
                    val acts = try { askGemini(prompt, shot) } catch (e: org.json.JSONException) { history.add("ошибка формата JSON, повтори"); continue }
                    for (i in 0 until acts.length()) {
                        if (!running) return@Thread
                        val a = acts.getJSONObject(i)
                        if (a.optString("action") != "done" && a.optString("action") != "say" && cfg.getBoolean("narrate", true)) a.optString("say").takeIf { it.isNotBlank() }?.let { speak(it) }
                        if (a.optString("action") == "done") { val s = a.optString("say", "Готово"); speak(s); stop(s); return@Thread }
                        val r = act(a); history.add("$a -> $r")
                        Thread.sleep(700)
                    }
                    Thread.sleep(900)
                }
                speak("Боюсь, задача оказалась сложнее ожидаемого, $me. Я остановился."); stop("Лимит шагов")
            } catch (e: Exception) { speak("Прошу прощения, $me. Возникла неполадка."); stop("Ошибка: ${e.message}") }
        }.start()
    }

    private fun readScreen(): String {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || !n.isVisibleToUser || out.size > 150) return
            if (n.isClickable || n.isEditable || n.isScrollable || n.isCheckable || !n.text.isNullOrBlank() || !n.contentDescription.isNullOrBlank()) out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        nodes = out
        return out.mapIndexed { i, n ->
            val f = listOfNotNull(if (n.isClickable) "click" else null, if (n.isEditable) "edit" else null, if (n.isScrollable) "scroll" else null,
                if (n.isChecked) "checked" else null, if (!n.isEnabled) "disabled" else null).joinToString(",")
            "$i|${n.className?.toString()?.substringAfterLast('.')}|${n.text?.toString()?.take(70) ?: ""}|${n.contentDescription?.toString()?.take(70) ?: ""}|$f"
        }.joinToString("\n").ifEmpty { "(пусто — экран защищён, грузится или нет доступных элементов; смотри скриншот)" }
    }

    private fun screenshot(): String? {
        val latch = CountDownLatch(1); var b64: String? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                try {
                    val sw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    r.hardwareBuffer.close()
                    if (sw != null) {
                        val s = Bitmap.createScaledBitmap(sw, 720, (sw.height * 720f / sw.width).toInt(), true)
                        val o = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 70, o)
                        b64 = Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
                    }
                } catch (e: Exception) {}
                latch.countDown()
            }
            override fun onFailure(code: Int) { latch.countDown() }
        })
        latch.await(5, TimeUnit.SECONDS); return b64
    }

    private fun pt(a: JSONObject): Pair<Float, Float>? {
        nodes.getOrNull(a.optInt("id", -1))?.let { val r = Rect(); it.getBoundsInScreen(r); return r.exactCenterX() to r.exactCenterY() }
        if (a.has("x") && a.has("y")) { val b = wm.maximumWindowMetrics.bounds; return (a.getDouble("x").toFloat() / 1000f * b.width()) to (a.getDouble("y").toFloat() / 1000f * b.height()) }
        return null
    }

    private fun act(a: JSONObject): String = try { run(a) } catch (e: Exception) { "ошибка: ${e.message}" }

    private fun run(a: JSONObject): String {
        val act = a.optString("action")
        val n = nodes.getOrNull(a.optInt("id", -1))
        val b = wm.maximumWindowMetrics.bounds; val w = b.width().toFloat(); val h = b.height().toFloat()
        fun go(i: Intent): String { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "ok" }
        fun focus() = n ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return when (act) {
            "open_app" -> {
                val pm = packageManager
                val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).firstOrNull { it.loadLabel(pm).toString().contains(a.optString("app"), true) }
                val li = ri?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                if (li != null) go(li) else "приложение не найдено; список: " + pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).joinToString { it.loadLabel(pm).toString() }.take(600)
            }
            "tap" -> pt(a)?.let { tap(it.first, it.second); "ok" } ?: "нет цели (id или x,y)"
            "double_tap" -> pt(a)?.let { tap(it.first, it.second); Thread.sleep(90); tap(it.first, it.second); "ok" } ?: "нет цели"
            "long_press" -> pt(a)?.let { gesture(Path().apply { moveTo(it.first, it.second); lineTo(it.first, it.second) }, 900); "ok" } ?: "нет цели"
            "swipe", "drag" -> {
                val p = Path().apply { moveTo(a.getDouble("x1").toFloat() / 1000 * w, a.getDouble("y1").toFloat() / 1000 * h); lineTo(a.getDouble("x2").toFloat() / 1000 * w, a.getDouble("y2").toFloat() / 1000 * h) }
                gesture(p, a.optLong("ms", if (act == "drag") 900 else 350)); "ok"
            }
            "scroll" -> {
                val (x1, y1, x2, y2) = when (a.optString("dir")) {
                    "up" -> listOf(w / 2, h * .3f, w / 2, h * .7f); "left" -> listOf(w * .2f, h / 2, w * .8f, h / 2)
                    "right" -> listOf(w * .8f, h / 2, w * .2f, h / 2); else -> listOf(w / 2, h * .7f, w / 2, h * .3f) }
                gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, 350); "ok"
            }
            "type" -> {
                val t = focus() ?: return "нет поля ввода (сначала нажми на него)"
                t.refresh()
                val old = if (a.optBoolean("append") && t.isEditable && !t.isShowingHintText) t.text?.toString() ?: "" else ""
                val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + a.optString("text")) }
                val ok = t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (ok && a.optBoolean("submit")) { Thread.sleep(400); t.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) }
                if (ok) "ok" else "не удалось ввести"
            }
            "edit" -> {
                val t = focus() ?: return "нет поля"
                val ok = when (a.optString("op")) {
                    "paste" -> t.performAction(AccessibilityNodeInfo.ACTION_PASTE); "copy" -> t.performAction(AccessibilityNodeInfo.ACTION_COPY)
                    "cut" -> t.performAction(AccessibilityNodeInfo.ACTION_CUT)
                    "select_all" -> t.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, Bundle().apply {
                        putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0); putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, t.text?.length ?: 0) })
                    "clear" -> t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") })
                    "enter" -> t.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                    else -> false }
                if (ok) "ok" else "не вышло"
            }
            "clipboard_set" -> { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", a.optString("text"))); "ok" }
            "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "ok" }
            "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "ok" }
            "recents" -> { performGlobalAction(GLOBAL_ACTION_RECENTS); "ok" }
            "notifications" -> { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); "ok" }
            "quick_settings" -> { performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); "ok" }
            "lock" -> { performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN); "ok" }
            "take_screenshot" -> { performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT); "ok" }
            "power_menu" -> { performGlobalAction(GLOBAL_ACTION_POWER_DIALOG); "ok" }
            "open_url" -> go(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))))
            "web_search" -> go(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", a.optString("query")))
            "maps" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("query")))))
            "dial" -> go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number"))))
            "sms" -> go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + a.optString("number"))).putExtra("sms_body", a.optString("text")))
            "alarm" -> go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute")).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "timer" -> go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "volume" -> {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                val dir = when (a.optString("dir")) { "up" -> AudioManager.ADJUST_RAISE; "down" -> AudioManager.ADJUST_LOWER; else -> AudioManager.ADJUST_TOGGLE_MUTE }
                repeat(a.optInt("times", 1)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI) }; "ok"
            }
            "flashlight" -> {
                val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                cm.setTorchMode(id, a.optBoolean("on", true)); "ok"
            }
            "say" -> { speak(a.optString("text")); toast(a.optString("text")); "ok" }
            "ask" -> ask(a.optString("question"))
            "wait" -> { Thread.sleep((a.optInt("sec", 2).coerceIn(1, 15)) * 1000L); "ok" }
            else -> "неизвестное действие"
        }
    }

    private fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y); lineTo(x, y) }, 60)
    private fun gesture(p: Path, dur: Long) {
        val latch = CountDownLatch(1)
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { latch.countDown() }
                override fun onCancelled(g: GestureDescription?) { latch.countDown() }
            }, null)
        latch.await(4, TimeUnit.SECONDS)
    }

    private fun persona() = "\n\nХАРАКТЕР: ты — ДЖАРВИС, ИИ-ассистент в стиле Железного человека: безупречно вежливый, сдержанный, с лёгкой сухой иронией. Обращайся к пользователю «$me». Все реплики — по-русски, коротко (до 12 слов), живо, как у дворецкого-ИИ: «Будет сделано, $me», «Открываю YouTube», «Нашёл. Включаю самое свежее», «Готово. Как всегда, без происшествий». " +
        "В любом действии можно добавить необязательное поле \"say\" — короткую реплику, которая прозвучит вслух перед действием; используй её на ключевых этапах (примерно раз в 2–3 шага), не болтай на каждом шаге. В done.say — итог или ответ на вопрос в этом стиле; длинные списки и ссылки вслух не зачитывай. В ask формулируй вопрос вежливо и кратко, в стиле Джарвиса."

    private fun askGemini(prompt: String, shot: String?): JSONArray {
        val key = cfg.getString("key", "") ?: ""; val model = cfg.getString("model", "gemini-2.5-flash")
        val sys = SYSTEM + persona() + if (cfg.getBoolean("confirm", true)) CONFIRM else ""
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (shot != null) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", shot)))
        val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        var txt = ""
        for (attempt in 1..3) {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 90000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            txt = (if (c.responseCode < 300) c.inputStream else c.errorStream).bufferedReader().readText()
            if (c.responseCode < 300) break
            if (attempt == 3 || c.responseCode !in listOf(429, 500, 503)) throw Exception("Gemini ${c.responseCode}: ${txt.take(150)}")
            Thread.sleep(3000L * attempt)
        }
        val t = JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            .trim().removePrefix("```json").removeSuffix("```").trim()
        return if (t.startsWith("[")) JSONArray(t) else JSONArray().put(JSONObject(t))
    }

    companion object {
        const val CONFIRM = "\nПЕРЕД необратимыми действиями (отправка сообщения/письма, оплата, покупка, удаление, публикация, звонок, перевод денег) вызови ask с вопросом и продолжай только если ответ «да». Пароли и коды не вводи, пока пользователь не продиктует их через ask."
        const val SYSTEM = """Ты — агент, который полностью управляет Android-телефоном по задаче пользователя. Каждый шаг тебе дают задачу, историю действий, список элементов экрана и (часто) скриншот. Ответь JSON: одним действием или массивом из 1–4 действий подряд (массив — только если экран между ними не меняет смысл, например type + нажатие поиска).
Координаты x,y всегда нормированы 0–1000 (левый верх 0,0; правый низ 1000,1000). Цель можно задавать через "id" из списка ИЛИ через x,y по скриншоту.
Действия:
{"action":"open_app","app":"название"}  {"action":"open_url","url":"..."}  {"action":"web_search","query":"..."}  {"action":"maps","query":"..."}
{"action":"tap","id":N} или {"action":"tap","x":..,"y":..}  double_tap, long_press — те же поля
{"action":"type","id":N,"text":"...","submit":true|false,"append":true|false}  (append — дописать к существующему тексту; id можно опустить, если поле в фокусе)
{"action":"edit","op":"paste|copy|cut|select_all|clear|enter"}  {"action":"clipboard_set","text":"..."}
{"action":"scroll","dir":"up|down|left|right"}  {"action":"swipe","x1":..,"y1":..,"x2":..,"y2":..,"ms":350}  {"action":"drag",...те же}
{"action":"back"} home recents notifications quick_settings lock take_screenshot power_menu (все без полей)
{"action":"dial","number":"..."}  {"action":"sms","number":"..","text":".."}  {"action":"alarm","hour":7,"minute":30,"label":".."}  {"action":"timer","seconds":300}
{"action":"volume","dir":"up|down|mute","times":3}  {"action":"flashlight","on":true}
{"action":"say","text":"..."} — сказать вслух; {"action":"ask","question":"..."} — спросить пользователя голосом и получить ответ (используй, если не хватает данных: что написать, кому, что выбрать)
{"action":"wait","sec":2}  {"action":"done","say":"итог или ответ на вопрос пользователя, коротко"}
Правила: если нужное приложение не открыто — open_app (или open_url). Если интент-действие (alarm, timer, dial, sms) подходит — используй его, это быстрее. Wi-Fi, Bluetooth, яркость и режимы включай через quick_settings или настройки. Если экран не изменился после действия — смени подход (другой элемент, x,y по скриншоту, scroll, back). Не повторяй одно действие больше 2 раз. Если для ответа нужно прочитать информацию с экрана — прочти и верни в done.say. Заверши done, когда задача выполнена или невозможна."""
    }
}
